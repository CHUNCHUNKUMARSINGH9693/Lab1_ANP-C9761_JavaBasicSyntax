public class PrimitiveDataTypesDemo {
  public static void main(String[] args) {
      byte byteValue = 10; 
      short shortValue = 1000; 
      int intValue = 100000; 
      long longValue = 10000000000L;
      float floatValue = 5.75f; 
      double doubleValue = 19.99; 
      char charValue = 'A'; 
      boolean booleanValue = true;

      System.out.println("Byte Value: " + byteValue);
      System.out.println("Short Value: " + shortValue);
      System.out.println("Integer Value: " + intValue);
      System.out.println("Long Value: " + longValue);
      System.out.println("Float Value: " + floatValue);
      System.out.println("Double Value: " + doubleValue);
      System.out.println("Character Value: " + charValue);
      System.out.println("Boolean Value: " + booleanValue);
  }
}
